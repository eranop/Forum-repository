package allcode;
/**
 * 
 * use to set operations of gold silver or regular member
 *
 */
public class MemberType {

}
